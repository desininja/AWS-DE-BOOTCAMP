import logging
import json
import boto3

logger = logging.getLogger()
logger.info("Just an information")

def lambda_handler(event, context):

    source_bucket = event['source_bucket']
    s3 = boto3.client('s3')

    response_contents = s3.list_objects_v2(Bucket = source_bucket).get('Contents')
    for rc in response_contents:
        file_size = rc.get('Size')/1024
        if file_size > 100:
            logger.info(f"Uploaded file size is greater than 100 MB")
            logger.info(f"Size: {file_size}")
        else:
            logger.info(f"Uploaded file size is not greater than 100 MB")
            logger.info(f"Size of file {file_size}")

    return {
        'statusCode': 200,
        'body': json.dumps('Lambda triggered on file upload')
    }
